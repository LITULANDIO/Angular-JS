angular.module('myApp')
  .factory('reposFactory', function($http) {

      function getRepos() {
        return $http.get('https://api.github.com/users/juanmaguitar/repos')
      }

      return {
        getRepos: getRepos
      }

  })